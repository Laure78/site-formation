---
name: consultation-fournisseurs
description: Prépare une consultation fournisseurs ou sous-traitants (demande de prix) et compare les offres reçues côté entreprise : périmètre, quantités, conditions, écarts, oublis, tableau comparatif et recommandation. Déclencher dès que l'utilisateur écrit « demande de prix », « consulter des fournisseurs », « comparer les devis fournisseurs », « comparatif sous-traitants », « quel fournisseur choisir », « consultation béton / acier / location », ou dépose plusieurs devis fournisseurs.
---

# Consultation fournisseurs & sous-traitants

**Public** : chargé d'études de prix, conducteur de travaux, dirigeant.
**Objectif** : consulter vite et comparer à périmètre égal (pas seulement au prix total).

## Deux modes
### A. Préparer la consultation
1. À partir du CCTP/DPGF ou de la liste de besoins, rédiger la **demande de prix** : objet, quantités, spécifications (normes, classes, finitions), lieu et accès chantier, planning de livraison/intervention, conditions de paiement [CONDITIONS ENTREPRISE], date limite de réponse.
2. Lister les **pièces à joindre** (extraits CCTP, plans, planning).
3. Produire le mail type à envoyer à chaque fournisseur.

### B. Comparer les offres reçues
1. Lire chaque devis et extraire : prix unitaires, quantités, total HT, transport/livraison, location/mise à disposition, délai, validité, conditions de paiement, exclusions et réserves.
2. **Ramener à périmètre égal** : signaler chaque poste absent ou exclu chez un fournisseur et le chiffrer « À CONFIRMER » plutôt que de l'ignorer.
3. Repérer les **écarts anormaux** (> 15 % par rapport à la moyenne) et les quantités qui ne correspondent pas au besoin.
4. Tableau comparatif + **questions à poser** à chaque fournisseur avant négociation.
5. Recommandation argumentée (prix, risques, délais) — la décision reste à l'acheteur.

## Format de sortie
Tableau comparatif (Excel ou tableau) + liste des oublis/réserves + mails de questions.

## Interdits
- Ne pas transmettre le prix d'un fournisseur à un autre.
- Ne pas recommander sur le seul prix total si les périmètres diffèrent.

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
