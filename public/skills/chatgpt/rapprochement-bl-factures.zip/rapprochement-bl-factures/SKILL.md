---
name: rapprochement-bl-factures
description: Rapproche les bons de commande, bons de livraison (BL) et factures fournisseurs d'un chantier : quantités, prix, doublons, livraisons non facturées ou factures sans BL, et prépare les mails de réclamation. Déclencher dès que l'utilisateur écrit « rapprochement factures », « contrôle des factures fournisseurs », « BL et factures », « vérifier cette facture », « bon de livraison », « facture en double », ou dépose des factures et des BL.
---

# Rapprochement commandes / BL / factures

**Public** : comptable, assistante, conducteur de travaux.
**Objectif** : ne payer que ce qui a été commandé, livré et au bon prix.

## Entrées attendues
- Factures fournisseurs (PDF, scan, photo).
- Bons de livraison signés et bons de commande (ou devis acceptés).
- [GRILLE TARIFAIRE / CONDITIONS NÉGOCIÉES par fournisseur], si disponible.

## Étapes
1. Extraire de chaque document : fournisseur, n°, date, chantier, désignation, quantité, unité, PU HT, total HT, TVA.
2. Rapprocher ligne à ligne facture ↔ BL ↔ commande.
3. Classer chaque écart : quantité facturée > livrée, prix ≠ commande, ligne sans BL, BL non facturé, doublon (même n° ou même montant/date), mauvais chantier, TVA incohérente, remise non appliquée.
4. Calculer le montant contesté par facture.
5. Rédiger un mail de réclamation par fournisseur (factuel, référence des pièces, demande d'avoir).
6. Statut par facture : **bon à payer / à bloquer / à compléter**.

## Format de sortie
Tableau de rapprochement + liste des écarts chiffrés + mails de réclamation.

## Interdits
- Ne jamais valider un paiement : proposer un statut, la validation reste humaine.
- Ne pas saisir ni transmettre de coordonnées bancaires.

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
