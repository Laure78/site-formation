---
name: journal-chantier-intemperies
description: Tient le journal de chantier quotidien (effectifs, météo, livraisons, événements, visiteurs) et prépare le dossier d'arrêt pour intempéries avec ses justificatifs. Déclencher dès que l'utilisateur écrit « journal de chantier », « main courante », « rapport journalier », « intempéries », « arrêt pour pluie / gel / vent », « chômage intempéries », « on a arrêté le chantier », ou dicte le déroulé de sa journée.
---

# Journal de chantier & intempéries

**Public** : conducteur de travaux, chef de chantier, assistante.
**Objectif** : garder une trace datée, utile en cas de retard, de litige ou de demande de prolongation de délai.

## Partie 1 — Journal quotidien
À partir d'une dictée ou de notes en vrac, produire une fiche datée :
- Date, chantier, rédacteur.
- Météo (constatée sur place + relevé de la station de référence [STATION / SOURCE MÉTÉO]).
- Effectifs par entreprise, matériel présent.
- Travaux réalisés / prévus non réalisés (et pourquoi).
- Livraisons, visites (MOE, CSPS, bureau de contrôle), incidents, réserves, photos prises.
- Faits pouvant justifier un retard : à signaler en **gras**.

## Partie 2 — Arrêt pour intempéries
1. Récapituler les journées ou heures arrêtées, le motif (pluie, gel, neige, vent…) et les tâches impossibles.
2. Lister les **justificatifs** à joindre : relevés météo, journal, photos, attestation, liste du personnel concerné.
3. Préparer le courrier/mail à la MOE informant de l'arrêt et réservant les droits sur le délai.
4. Préparer le récapitulatif pour la déclaration à la caisse de congés intempéries [CAISSE CIBTP RÉGIONALE] — **conditions, seuils et délais à vérifier auprès de la caisse** : ne pas les supposer.

## Format de sortie
Fiche journal (1 page/jour) + dossier intempéries + courrier MOE.

## Interdits
- Ne pas inventer de relevé météo : sans source, noter « À CONFIRMER ».
- Ne pas affirmer l'éligibilité à une indemnisation : la caisse décide.

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
