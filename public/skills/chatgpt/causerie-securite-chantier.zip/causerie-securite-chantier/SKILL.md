---
name: causerie-securite-chantier
description: Prépare un quart d'heure sécurité (causerie) adapté à la phase de chantier : risque du jour, messages clés, questions aux compagnons, fiche d'émargement et suivi des remontées. Déclencher dès que l'utilisateur écrit « quart d'heure sécurité », « causerie sécurité », « accueil sécurité », « toolbox », « sensibiliser l'équipe », « point sécurité du lundi », ou décrit une phase (coffrage, travail en hauteur, levage, tranchée…).
---

# Quart d'heure sécurité (causerie)

**Public** : conducteur de travaux, chef de chantier, directeur technique.
**Objectif** : 10-15 min utiles sur le risque réel de la semaine, tracées.

## Entrées attendues
- Phase et tâches de la semaine, engins et matériels, coactivité.
- Incidents ou presqu'accidents récents.
- [EXTRAITS DUERP / PPSPS de l'entreprise] si disponibles.

## Étapes
1. Choisir **un seul risque principal** (ex. chute de hauteur en coffrage de voile, renversement d'engin, ensevelissement en tranchée).
2. Rédiger la causerie : situation concrète du chantier, 3 messages clés, les bons gestes, les EPI/EPC concernés.
3. Prévoir **3 questions** à poser aux compagnons (faire parler, pas faire un cours).
4. Version courte simplifiée si besoin (phrases courtes, pictogrammes suggérés) pour des équipes non francophones.
5. Fiche d'émargement (date, thème, animateur, participants, signature).
6. Tableau des remontées terrain : point soulevé, action, responsable, échéance.

## Format de sortie
Fiche causerie 1 page + émargement + tableau des remontées.

## Interdits
- Ne pas remplacer le PPSPS, le DUERP ni l'avis du préventeur/CSPS.
- Ne pas citer d'article réglementaire sans source : sinon « référence à vérifier (OPPBTP / Code du travail) ».

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
