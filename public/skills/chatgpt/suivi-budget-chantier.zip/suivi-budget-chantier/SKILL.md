---
name: suivi-budget-chantier
description: Suit le budget d'un chantier côté entreprise : budget prévu vs dépenses engagées et réalisées, reste à dépenser, avancement facturé, marge à terminaison et alertes. Déclencher dès que l'utilisateur écrit « suivi budget chantier », « point financier chantier », « où en est la marge », « dépenses du chantier », « reste à dépenser », « marge à terminaison », « on dépasse ? », ou dépose un export comptable, des factures ou un budget de chantier.
---

# Suivi budget & marge de chantier

**Public** : dirigeant, directeur technique, conducteur de travaux.
**Objectif** : voir tôt un chantier qui dérape, avec des chiffres traçables.

## Entrées attendues
- Budget de l'affaire (déboursé sec prévu par poste : MO, matériaux, matériel, sous-traitance, frais) — [MODÈLE BUDGET ENTREPRISE].
- Dépenses : export comptable, factures fournisseurs, heures pointées × [TAUX HORAIRE CHARGÉ].
- Facturation : situations émises, TS acceptés.
- Avancement physique estimé par poste (%).

## Étapes
1. Structurer les dépenses par poste budgétaire ; lister les lignes non affectées.
2. Calculer par poste : budget, engagé, réalisé, reste à dépenser estimé, **coût à terminaison**.
3. Comparer avancement physique et avancement financier ; calculer la **marge à terminaison** (montant et %).
4. Alertes : poste > 90 % consommé pour < 80 % d'avancement, TS non facturés, factures sans bon de commande.
5. Synthèse dirigeant (5 lignes) + 3 actions correctives proposées.

## Format de sortie
Tableau Excel avec formules visibles + synthèse courte. Chaque chiffre renvoie à sa source.

## Interdits
- Ne pas extrapoler un coût à terminaison sans afficher l'hypothèse utilisée.
- Ne pas modifier les chiffres comptables : signaler les incohérences.

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
