---
name: travaux-supplementaires-ts
description: Prépare une fiche de travaux supplémentaires (TS) ou modificatifs côté entreprise : origine de la demande, description, chiffrage justifié, impact délai, courrier de transmission à la MOE/MOA. Déclencher dès que l'utilisateur écrit « travaux supplémentaires », « TS », « travaux modificatifs », « devis complémentaire », « demande d'avenant », « la MOE nous demande en plus », « hors marché », ou dépose un OS, un mail ou un CR qui ajoute une prestation.
---

# Travaux supplémentaires & modificatifs (TS)

**Public** : conducteur de travaux, chargé d'études de prix.
**Objectif** : ne plus réaliser de travaux non payés — tracer la demande, chiffrer, faire valider AVANT exécution.

## Entrées attendues
- La demande (mail, CR, OS, plan modifié, photo) et la date à laquelle elle a été reçue.
- Le marché : CCAP/CCTP/DPGF ou le devis initial (pour vérifier si la prestation est déjà due).
- Le bordereau de prix de l'entreprise : [BPU / base de prix interne].

## Étapes
1. **Qualifier** : la prestation figure-t-elle déjà au marché (CCTP, DPGF, sujétions) ? Citer l'article. Si oui → signaler « déjà dû, pas de TS » et expliquer.
2. **Identifier l'origine** : demandeur, date, support écrit. Sans écrit → rédiger d'abord un mail de confirmation de la demande.
3. **Décrire** la prestation : localisation, quantités, matériaux, contraintes d'exécution.
4. **Chiffrer** : prix du marché (BPU) quand ils existent, sinon prix nouveaux décomposés (MO, matériaux, matériel, sous-traitance, frais, marge [COEF]). Afficher le détail du calcul.
5. **Impact délai et planning** : jours supplémentaires, tâches impactées, interfaces avec d'autres lots.
6. **Rédiger** le courrier/mail de transmission : demande d'accord écrit (OS ou avenant) avant exécution, délai de réponse souhaité.
7. **Tableau de suivi** des TS du chantier : n°, objet, montant HT, date d'envoi, statut (envoyé / accepté / refusé / exécuté / facturé).

## Format de sortie
Fiche TS (1 page) + courrier de transmission + ligne du tableau de suivi. Montants en € HT.

## Interdits
- Ne jamais conseiller d'exécuter avant accord écrit.
- Ne pas qualifier juridiquement un litige : renvoyer vers la direction ou un conseil si la MOE refuse.

## Règles communes
- Ne jamais inventer un chiffre, une date, un nom, une référence de marché ou de norme : toute donnée absente est notée **À CONFIRMER**.
- Citer la source de chaque élément repris (document, page, article, n° de ligne).
- Données sensibles (prix, salaires, données personnelles) : travailler sur des documents anonymisés si la politique de l'entreprise l'exige.
- Le résultat est un **brouillon à valider** par la personne responsable avant tout envoi ou décision.
- Zones à compléter par l'entreprise : signalées entre [CROCHETS] dans ce fichier.
- Terminer chaque livrable par une **check-list de vérification** (3 à 6 points).
