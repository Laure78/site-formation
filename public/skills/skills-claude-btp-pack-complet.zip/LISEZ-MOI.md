# 5 Skills Claude pour les entreprises du BTP

Offerts par **Laure OLIVIÉ - OFC Création d'Entreprise**, formatrice IA BTP.

| Skill | Pour qui | Ce qu'il fait |
|---|---|---|
| analyse-cctp-gros-oeuvre | Chargé d'études, conducteur de travaux | Analyse un CCTP et liste exigences, risques et questions à la MOE |
| actions-compte-rendu-chantier | Conducteur de travaux | Extrait les actions qui/quoi/quand d'un CR de chantier |
| controle-devis-oublis | Chargé d'études de prix, dirigeant | Contrôle un devis et repère les oublis avant envoi |
| courriers-relances-btp | Assistante, comptable, conducteur | Rédige courriers et relances (paiement, MOE, fournisseurs) |
| methodologie-execution-gros-oeuvre | Directeur technique, dirigeant | Structure une méthodologie d'exécution / mémoire technique |

## Installation (2 minutes)
1. Ouvrez **claude.ai** → **Paramètres** → **Fonctionnalités / Capacités** → **Skills**.
2. Cliquez sur **Importer un skill** et sélectionnez le fichier **.zip** du skill choisi.
3. Activez-le, puis demandez simplement à Claude : « Analyse ce CCTP » en joignant votre document.

La méthode : **choisir une tâche → définir les consignes → tester → ajuster.**
Complétez les zones [À COMPLÉTER] de chaque skill avec les méthodes de votre entreprise.

⚠️ Toujours vérifier les sources et les résultats avant utilisation.

## Aller plus loin
Formation « Créer des assistants IA avec Claude » en intra ou inter, en présentiel en Île-de-France.
Prise en charge OPCO/Constructys selon éligibilité. Organisme certifié Qualiopi.

www.laureolivie.fr · contact@laureolivie.fr · 06 95 66 18 18

© OFC Création d'Entreprise - SIRET 905 244 281 00010 - NDA 11788515078. Usage libre en interne, revente interdite.
